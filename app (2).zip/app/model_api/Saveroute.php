<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Saveroute extends Model
{
    use HasFactory;
   protected $table = 'saved_routes';
}
