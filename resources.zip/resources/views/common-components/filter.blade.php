<div id="custom_saction_filter">
    <button type="button" style="height: 47px; line-height:10px;"
        class="btn custom_main_saction header-item noti-icon fil_ waves-effect" onclick="openNav()">
        <i class="bx bx-filter-alt"></i>
    </button>
    <div data-simplebar class="h-100">
        <div class="rightbar-title p-3">
            <a href="javascript:void(0);" class="custom_saction_filter float-right" onclick="closeNav()">
                <i class="mdi mdi-close noti-icon" style="color:#fff;"></i>
            </a>
            <h5 class="m-0" style="color:#6a7187;">Filter</h5>
        </div>


        <hr class="mt-0" style="background: #61687e;" />
        <div class="custom_form">
            <div class="form-group">
                <label for="example-text-input" class="text-cutom col-form-label" style="padding-top: 0;">Text</label>
                <input class="form-control" type="text" value="Artisanal kale" id="example-text-input">
            </div>
            <div class="form-group">
                <label for="example-text-input pt-0" class="text-cutom col-form-label"
                    style="padding-top: 0;">Date</label>
                <input class="form-control" type="date" value="2019-08-19" id="example-date-input">
            </div>
            <div class="form-group">
                <label for="example-text-input pt-0" class="text-cutom col-form-label"
                    style="padding-top: 0;">Select</label>
                <select class="form-control">
                    <option>Select</option>
                    <option>Large select</option>
                    <option>Small select</option>
                </select>
            </div>
            <div class="custom-control custom-checkbox custom-checkbox-primary mb-2">
                <input type="checkbox" class="custom-control-input" id="customCheckcolor1">
                <label class="text-cutom custom-control-label" for="customCheckcolor1">Checkbox Primary</label>
            </div>
            <div class="custom-control custom-radio custom-radio-primary mb-2">
                <input type="radio" id="customRadiocolor1" name="customRadiocolor1" class="custom-control-input">
                <label class="text-cutom custom-control-label" for="customRadiocolor1">Custom Radio Primary</label>
            </div>
            <div class="custom-control custom-switch mb-2" dir="ltr">
                <input type="checkbox" class="custom-control-input" id="customSwitch1">
                <label class="text-cutom custom-control-label" for="customSwitch1">Toggle this switch element</label>
            </div>
        </div>
    </div>
</div>