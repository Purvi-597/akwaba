<html lang="en-US">
  <head>
    <meta charset="utf-8" />
  </head>
  <body>
    <h4>Email Verification</h4>
    <a href="https://tiecmobile.dadenllc.com/pages-main?id={{$_SESSION['temp']}}">Verify Mail</a>
   
  </body>
</html>
