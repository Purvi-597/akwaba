 @extends('layouts.master')
@section('title')  Add feature List @endsection
@section('css')
<link rel="stylesheet" type="text/css" href="{{ URL::asset('assets/libs/summernote/summernote.min.css')}}">
@endsection
@section('content')
@component('common-components.breadcrumb')
@slot('title') Add feature list @endslot
@endcomponent
<style>
.form-control{
	color: #314667 !important;
}

input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
  -webkit-appearance: none;
  margin: 0;
}
.disable{
   cursor: not-allowed;
   pointer-events: none;
}
</style>

<div class="row">
    <div class="col-12">
        <div class="card mb-2">
           <div class="card-body">
                  @if (Session::get('error'))
                        <div class="alert alert-danger alert-block">
                            <button type="button" class="close" data-dismiss="alert">×</button> 
                                <strong>{{ Session::get('error') }}</strong>
                        </div>
                    @endif
                    @if (Session::get('success'))
                        <div class="alert alert-success alert-block">
                            <button type="button" class="close" data-dismiss="alert">×</button> 
                                <strong>{{ Session::get('success') }}</strong>
                        </div>
                    @endif


            <form name="frm1" id="frm1" class="needs-validation" method="post" enctype="multipart/form-data" action="{{route('feature_list.store')}}"  onclick="return CheckDimension()" novalidate>
                 @csrf
                 <div class="form-group">
                    <label>Choose a Feature Places:</label>
                    <select id="featured_places_id" name="featured_places_id" class="form-control">
                      <option value="">Select Feature Places</option>
                      @foreach($feature_list as $feature)
                        <option value="{{ $feature->id }}">{{ $feature->title }}</option>
                      @endforeach
                    </select>
                  </div>

                    <div class="form-group">
                        <label for="formrow-quest_name-input"> Title</label>
						<input type="text" class="form-control" name="title" id="title" placeholder="Enter Title" value="{{old('title')}}" required>
                        <div class="invalid-feedback">
                            Please provide a Title.
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="formrow-quest_name-input">French Title</label>
						<input type="text" class="form-control" name="title_fr" id="title_fr" placeholder="Enter French Title" value="{{old('title_fr')}}" required>
                        <div class="invalid-feedback">
                            Please provide a French Title.
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="formrow-quest_name-input"> Description</label>
						<input type="text" class="form-control" name="description" id="description" placeholder="Enter Description" value="{{old('description')}}" required>
                        <div class="invalid-feedback">
                            Please provide a Description.
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="formrow-quest_name-input">French  Description</label>
						<input type="text" class="form-control" name="description_fr" id="description_fr" placeholder="Enter Description" value="{{old('description_fr')}}" required>
                        <div class="invalid-feedback">
                            Please provide a Description.
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="formrow-quest_name-input"> Ratings</label>
						<input type="number" class="form-control" name="ratings" id="ratings" placeholder="Enter ratings" value="{{old('ratings')}}" required>
                        <div class="invalid-feedback">
                            Please provide a Description.
                        </div>
                    </div>
    
                    <div id="req_input" class="form-group">
                        <label for="formrow-quest_name-input"> Image</label>
                        <input type="file"  class="form-control images" name="image" id="images_0" required >
                            <div class="invalid-feedback">
                                   Please select Image
                            </div><br>
                        <img id="image_main0" name="image_main0" class="image_main0" height="100" width="100" style="display:none" >
                        <span id="image0_error" style="color:#f46a6a;margin-top: 0.25rem;font-size: 80%;"></span>
                    </div>

                    <div class="col-md-2" style="padding-top:1%;">
                        <div class="form-group ">
                            <div class="custom-control custom-checkbox">
                                @php $checked=""; @endphp
                                <input type="checkbox" name="status" class="custom-control-input" id="invalidCheck" >
                                <label class="custom-control-label" for="invalidCheck" >Active</label>
                                <div class="invalid-feedback">
                                    You must agree before Save.
                                </div>
                            </div>

                        </div>
                    </div>
                        
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group ">
                                <button class="btn btn-success" type="submit" id="save">Save</button>
                            <a href="../feature_list" class="btn btn-danger">Cancel</a>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div> <!-- end col -->
</div>
<!-- end row -->
@endsection
@section('script')
<script src="{{ URL::asset('assets/libs/parsleyjs/parsleyjs.min.js')}}"></script> 
<script src="{{ URL::asset('assets/js/pages/form-validation.init.js')}}"></script>
<script src="{{ URL::asset('assets/libs/bootstrap-maxlength/bootstrap-maxlength.min.js')}}"></script>
<script src="{{ URL::asset('assets/js/pages/form-advanced.init.js')}}"></script>
<script src="{{ URL::asset('assets/libs/tinymce/tinymce.min.js')}}"></script>
<script src="{{ URL::asset('assets/libs/summernote/summernote.min.js')}}"></script>
<script src="{{ URL::asset('assets/js/pages/form-editor.init.js')}}"></script>

<script>
    var _URL = window.URL || window.webkitURL;
   $(document).on('change','#images_0',function(e){
    var file, img;
   
    let name = e.target.files[0].name;
   if ((file = this.files[0])) {
     var ext = name.split('.').pop().toLowerCase();
   
     if($.inArray(ext, ['png','jpg','jpeg']) == -1) {
     $("#image0_error").text("Please upload images of following formats(*png,jpeg,jpg).");
     $("#images_0").val("");
     $("#images_0").val(null);
       $("#image_main0").attr('src','');
         $("#image_main0").css('display','none');
   
     }else{
   
           var imgwidth = 0;
           var imgheight = 0;
           var maxwidth = 400;
           var maxheight = 280;
           img = new Image();
           img.onload = function() {
   
           imgwidth = this.width;
           imgheight = this.height;
   
           if(imgwidth > maxwidth && imgheight > maxheight){
   
           $("#image0_error").text("Please upload images of following dimension width/height(400*280).");
           $("#image_main0").css("display", "none");
           $("#image_main0").attr('src','');
           $("#images_0").val("");
           }else{
           $("#image0_error").text("");
           $("#image_main0").css("display", "block");
           $('#image_main0').attr('src', img.src).height(280).width(400);
               }
           }
       };
           img.src = _URL.createObjectURL(file);
   }
   });
   </script>
@endsection
