<html lang="en-US">
  <head>
    <meta charset="utf-8" />
  </head>
  <body>
    <h2>Request for Money</h2>
    <h4>{{$_SESSION['message']}}</h4>
   
  </body>
</html>
